# -*- coding: utf-8 -*-
"""
@author: mlaurent,dlabaste
controller de jeu Blokus
"""

from ihm import *

#LANCER MENU
charger_menu()

#LANCER PARAMETRES
# charger_settings("menu")

#LANCER CREDITS
# charger_credits()

#LANCER ECRAN DE FIN ([[score_j1,0][score_j2,1][score_j3,2][score_j4,3]])
# charger_final([[10,0][9,1][8,2][7,3]])











			













	
	

